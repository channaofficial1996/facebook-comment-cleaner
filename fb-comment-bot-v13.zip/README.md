# Facebook Comment Bot v13

Deploy to Railway or run locally.